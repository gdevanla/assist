/**
 * Some utility classes to read problems from plain text files.
 */

package org.sat4j.reader;

