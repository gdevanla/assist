/**
 * Implementation of different encodings.
 */

package org.sat4j.tools.encoding;

