/**
 * Implementations of cardinality constraints.
 * 
 * Cardinality constraints are implemented by counters and watched literals.
 */

package org.sat4j.minisat.constraints.card;

