Total number of tests: 2340

How to run the tests:IDE : Eclipse API: JUnit 41)	Create a new project named sat4j in eclipse and import the contents of sat4j project into the folder.2)	To run only the unit tests run : AllUnitTests.java (inside org package)3)	To run only the acceptance tests run : AllTest.java (inside org.sat4j.minisat package)Note: 1) Increase the heap size in eclipse before running tests to avoid out of memory exception
      2) mockito has been used for some tests so install mockito before running tests.